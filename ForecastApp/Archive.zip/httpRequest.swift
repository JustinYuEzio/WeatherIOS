//
//  httpRequest.swift
//  ForecastApp
//
//  Created by Hengyi Yu on 11/22/19.
//  Copyright © 2019 Hengyi Yu. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON
import SwiftSpinner
protocol HttpRequestDelegate {
    func didUpdateWeather(weather: WeatherDisplay)
    func didGetCity(cityData: CityData)
    func didGetLocation(location: Location)
}
protocol ImageDelegate {
    func didGetImage(image: ImageData)
}
struct HttpRequest {
    let weatherURL = "http://justin-csci571-hw8fornodejs.us-east-2.elasticbeanstalk.com/weather"
    let autoCompleteURL =
    "http://justin-csci571-hw8fornodejs.us-east-2.elasticbeanstalk.com/auto_complete"
    let imageURL = "http://justin-csci571-hw8fornodejs.us-east-2.elasticbeanstalk.com/image"
    let locationURL = "http://justin-csci571-hw8fornodejs.us-east-2.elasticbeanstalk.com/location"
    var delegate: HttpRequestDelegate?
    var imageDelegate: ImageDelegate?
    func convertURL(link: String) -> URL {
        let urlStr : String = link.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let convertedURL : URL = URL(string: urlStr)!
        return convertedURL
    }
    func getCity(cityName: String) {
        let params: Parameters  = ["city": cityName];
        AF.request(autoCompleteURL,parameters: params,encoding: URLEncoding(destination: .queryString)).responseData { (response) -> Void in
            switch response.result {
            case .success(let data):
                if let cityData = self.parseCityJSON(cityData: data) {
                    self.delegate?.didGetCity(cityData: cityData)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getImage(cityName: String) {
        let params: Parameters = ["address": cityName]
        SwiftSpinner.show("Fetching data from Google...")
        AF.request(imageURL, parameters: params,encoding: URLEncoding(destination: .queryString)).responseData { (response) -> Void in
            switch response.result {
            case .success(let data):
                if let image = self.parseImageJson(image: data) {
                    self.imageDelegate?.didGetImage(image: image)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getLocation(description: String) {
        let index = description.firstIndex(of: ",")
        let cityName = description.prefix(upTo: index!)
        SwiftSpinner.show("Fetching weather Data for " + cityName)
        let params: Parameters  = ["address": description];
        AF.request(locationURL,parameters: params,encoding: URLEncoding(destination: .queryString)).responseData { (response) -> Void in
            switch response.result {
            case .success(let data):
                if let location = self.parseLocationJSON(locationData: data) {
                    let VC = ViewController()
                    
                    VC.lat = location.lat
                    VC.lng = location.lng
                    self.delegate?.didGetLocation(location: location)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getWeather(lat: Double, lng: Double) {
        
        let params: Parameters  = ["lat": lat, "lng": lng];
        AF.request(weatherURL,parameters: params,encoding: URLEncoding(destination: .queryString)).responseData { (response) -> Void in
            switch response.result {
            case .success(let data):
                if let weather = self.parseWeatherJSON(weatherData: data) {
                    self.delegate?.didUpdateWeather(weather: weather)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func parseImageJson(image: Data) -> ImageData? {
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(ImageData.self, from: image)
            let images = ImageData(items: decodedData.items)
            return images
            
        } catch {
            print(error)
            return nil
        }
    }
    func parseWeatherJSON(weatherData: Data) -> WeatherDisplay? {
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(WeatherData.self, from: weatherData)
            let weather = WeatherDisplay(
                summary: decodedData.currently.summary,
                temperature: decodedData.currently.temperature,
                humidity: decodedData.currently.humidity,
                windSpeed: decodedData.currently.windSpeed,
                visibility: decodedData.currently.visibility,
                pressure: decodedData.currently.pressure,
                icon: decodedData.currently.icon,
                daily: decodedData.daily,
                prec: decodedData.currently.precipProbability,
                ozone: decodedData.currently.ozone,
                cc: decodedData.currently.cloudCover)
                SwiftSpinner.hide()
             return weather
        } catch {
            print(error)
            return nil
        }
       
    }
    func parseCityJSON(cityData: Data) -> CityData? {
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(CityData.self, from: cityData)
            let cities = CityData(predictions: decodedData.predictions)
            return cities
            
        } catch {
            print(error)
            return nil
        }
       
    }
    func parseLocationJSON(locationData: Data) -> Location?{
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(LocationData.self, from: locationData)
            
            let lat = decodedData.results[0].geometry.location.lat
            let lng = decodedData.results[0].geometry.location.lng
            let loc = Location(lat: lat, lng: lng)
            SwiftSpinner.hide()
            return loc
        } catch {
            print(error)
            return nil
        }
       
    }
    

}
